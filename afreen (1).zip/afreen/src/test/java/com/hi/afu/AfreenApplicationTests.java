package com.hi.afu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfreenApplicationTests {

	@Test
	void contextLoads() {
	}

}
